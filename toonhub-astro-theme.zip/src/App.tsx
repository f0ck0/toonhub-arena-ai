import { useState } from "react";

/* ======================================================================
 * TOONHUB 独立站审计报告 —— React 展示壳
 *
 * ⚠️ 本文件仅是 arena 环境的 React 包装层(可随时删除)。
 * 真正的独立站项目在仓库根目录的 `toonhub-astro/` 文件夹中
 * (Astro 7 + Medusa,server 输出)。删除本 React 工程后,
 * 把 toonhub-astro/ 单独拿走即可正常开发、构建、部署。
 * ==================================================================== */

type Section = "bugs" | "fixes" | "advice" | "medusa" | "verify";

const NAV: { key: Section; label: string }[] = [
  { key: "bugs", label: "① 修复的 Bug" },
  { key: "fixes", label: "② 已实施的优化" },
  { key: "advice", label: "③ 前端建议" },
  { key: "medusa", label: "④ Medusa 后端建议" },
  { key: "verify", label: "⑤ 验证结果" },
];

const BUGS = [
  {
    where: "package.json",
    issue: "图片服务动态 import(\"sharp\") 但 sharp 不在依赖里 —— npm 靠传递依赖碰巧可用，pnpm 严格模式/升级 Astro 即挂",
    fix: "sharp ^0.35.4 加入 dependencies；移除从未使用的 pg",
  },
  {
    where: "src/lib/images.ts · src/lib/fallback.ts",
    issue: "系列图映射错误：Naruto 显示 Solo Leveling 图、Tokyo Revengers 显示 Sailor Moon 图、Digimon 显示 Gundam 图",
    fix: "新生成 3 张正确封面 webp，修正两处映射",
  },
  {
    where: "api/cart/add.ts · update.ts · remove.ts",
    issue: "购物车接口零校验：负数/超大数量、空 cartId/variantId 直接打向 Medusa",
    fix: "必填校验 + 数量 1–99，返回 400 与明确错误",
  },
  {
    where: "api/reviews.ts",
    issue: "评分可为 99、文本无限长，可被刷评灌水滥用",
    fix: "评分钳制 1–5，文本/标题/名字长度上限，图片 ≤5 张",
  },
  {
    where: "api/newsletter.ts",
    issue: "邮箱校验仅 includes(\"@\")，\"a@b\" 也能订阅",
    fix: "严格邮箱正则 + 254 字符上限",
  },
  {
    where: "src/lib/site.ts",
    issue: "sameAs 指向 instagram.com 首页占位链接，Google 判为无效外链拉低 Organization 可信度",
    fix: "置空过滤，注释说明填入真实主页后自动恢复",
  },
];

const FIXES = [
  {
    title: "电商转化埋点（此前全站缺失 ❗）",
    desc: "原站只有匿名行为上报，没有任何 GA4 / GTM / Meta Pixel —— 广告无法回传转化。新增 src/scripts/lib/analytics.ts 事件中心，统一 push 到 dataLayer（GTM/GA4 通用协议）+ 有 Pixel 时同步 fbq。",
    items: [
      "view_item — PDP 首屏曝光（pdp.ts）",
      "add_to_cart — 加购成功含商品/价格/数量（cart.ts）",
      "begin_checkout — 进入结账页（checkout.ts）",
      "purchase — 下单成功含订单号/金额/币种（success.astro 服务端注入）",
      "Base.astro 环境变量驱动加载器：GA4_ID / GTM_ID / FB_PIXEL_ID，未配置时零广告脚本",
    ],
  },
  {
    title: "商品结构化数据增强（Google 富结果）",
    desc: "productJsonLd() 增加 shippingDetails（全球免运费）、hasMerchantReturnPolicy（30 天退货）、priceValidUntil —— 搜索结果可获得免运费/可退货徽标，提升 CTR。",
    items: [],
  },
  {
    title: "购物车 API 安全加固",
    desc: "add / update / remove 三个接口入参校验，防止异常请求穿透到 Medusa 产生脏数据。",
    items: [],
  },
];

const ADVICE = [
  { level: "高", text: "社交账号真实化 —— 站内无任何真实社媒链接，补 Instagram/TikTok/Facebook 主页" },
  { level: "高", text: "CSP 安全头 —— 上 CDN 后加 Content-Security-Policy，营销脚本统一由 GTM 托管" },
  { level: "高", text: "移除滚动假倒计时 —— SALE_WINDOW_DAYS 是每访客 3 天滚动结束的暗模式，长期伤害品牌信任，建议改真实促销日历" },
  { level: "中", text: "结算地址校验 —— 接入 Google Address Autocomplete + 邮编格式库" },
  { level: "中", text: "订单状态页增强 —— 支持一键注册账号、重购（数据已在 localStorage toonhub_orders）" },
  { level: "中", text: "多语言 URL 路由 —— 字典已备好 zh-Hant/ja，商品描述多语言后再上 /ja/… 目录 + hreflang" },
  { level: "中", text: "评论审核队列 —— 建议后端加 draft→published 状态（前端已做长度限制）" },
  { level: "低", text: "搜索同义词表 —— 提高长尾命中（如 shikishi→色纸）" },
  { level: "低", text: "A/B 实验开关 —— offer 文案与 CTA 颜色预留测试位" },
];

const MEDUSA_ADVICE = [
  "支付回调幂等：确认 Stripe/PayPal webhook 幂等处理，防重复发货",
  "订单邮件：确认配置 SMTP 与 OrderPlaced 模板（成功页承诺发邮件）",
  "评论审核：后端加审核状态与脏词过滤",
  "速率限制：/api/reviews、/api/contact、/api/newsletter 在网关层加 rate limit",
  "促销配置接口化：前端 auto-apply 折扣码依赖多路径猜测，建议后端出单一 /store/promo 接口（code/折扣率/开关）",
  "多币种：前端静态汇率仅展示，结账仍 USD —— 开多区域 + 价格表，或明确只收 USD",
  "运费档：isConfiguredShip() 在过滤占位运费，说明后端运费档未配置 —— 建议配置真实免运费规则",
  "库存模块：开 inventory 并在 variant 维护真实库存，前端缺货徽标已有结构化数据支持",
];

const VERIFY = [
  { label: "astro check（类型检查）", result: "0 errors · 0 warnings" },
  { label: "astro build（生产构建）", result: "成功，server 输出 dist/" },
  { label: "vitest run（测试套件）", result: "120/120 通过（10 个文件）" },
  { label: "Node 版本", result: "要求 ≥ 22.12（engines 已声明）" },
];

export default function App() {
  const [tab, setTab] = useState<Section>("bugs");

  return (
    <div className="min-h-screen bg-[#05060a] text-zinc-100">
      {/* 顶部横幅 */}
      <header className="border-b border-white/10 bg-gradient-to-r from-[#0a0d16] via-[#101423] to-[#0a0d16]">
        <div className="mx-auto max-w-5xl px-5 py-10">
          <p className="text-[11px] font-bold tracking-[0.3em] text-orange-400">
            AUDIT REPORT · 2026
          </p>
          <h1 className="mt-3 text-3xl font-black tracking-tight md:text-4xl">
            TOONHUB 独立站
            <span className="ml-2 bg-gradient-to-r from-orange-400 to-rose-500 bg-clip-text text-transparent">
              全面审计与修复
            </span>
          </h1>
          <p className="mt-4 max-w-2xl text-sm leading-relaxed text-zinc-400">
            下载仓库 <code className="rounded bg-white/10 px-1.5 py-0.5 text-orange-300">f0ck0/Toonhub-Astro-Theme</code>{" "}
            后逐文件审查 + 自动检查（astro check / build / vitest）。
            <strong className="text-zinc-200">真正的项目位于 toonhub-astro/ 文件夹（Astro 7 + Medusa 独立站）</strong>，
            本页面只是 arena 环境的 React 包装层，删除本工程即可单独使用 toonhub-astro。
          </p>
          <div className="mt-6 flex flex-wrap gap-2 text-xs">
            {["Astro 7", "Medusa 2.x", "Node ≥22", "输出 server", "120 测试通过"].map((chip) => (
              <span key={chip} className="rounded-full border border-white/15 bg-white/5 px-3 py-1.5 text-zinc-300">
                {chip}
              </span>
            ))}
          </div>
        </div>
      </header>

      {/* 导航 */}
      <nav className="sticky top-0 z-10 border-b border-white/10 bg-[#05060a]/90 backdrop-blur">
        <div className="mx-auto flex max-w-5xl gap-1 overflow-x-auto px-5 py-2">
          {NAV.map((item) => (
            <button
              key={item.key}
              onClick={() => setTab(item.key)}
              className={`whitespace-nowrap rounded-lg px-3.5 py-2 text-sm font-semibold transition ${
                tab === item.key
                  ? "bg-orange-500/15 text-orange-300"
                  : "text-zinc-400 hover:bg-white/5 hover:text-zinc-200"
              }`}
            >
              {item.label}
            </button>
          ))}
        </div>
      </nav>

      <main className="mx-auto max-w-5xl px-5 py-10">
        {tab === "bugs" && (
          <section className="space-y-4">
            <h2 className="text-xl font-bold">① 已修复的 Bug（6 类）</h2>
            {BUGS.map((bug, i) => (
              <article key={i} className="rounded-xl border border-white/10 bg-white/[0.03] p-5">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="rounded bg-rose-500/15 px-2 py-0.5 font-mono text-xs text-rose-300">BUG {i + 1}</span>
                  <code className="text-xs text-orange-300">{bug.where}</code>
                </div>
                <p className="mt-3 text-sm leading-relaxed text-zinc-300">❌ {bug.issue}</p>
                <p className="mt-2 text-sm leading-relaxed text-emerald-300">✅ {bug.fix}</p>
              </article>
            ))}
          </section>
        )}

        {tab === "fixes" && (
          <section className="space-y-4">
            <h2 className="text-xl font-bold">② 已实施的独立站优化</h2>
            {FIXES.map((fix, i) => (
              <article key={i} className="rounded-xl border border-white/10 bg-white/[0.03] p-5">
                <h3 className="font-bold text-emerald-300">{fix.title}</h3>
                <p className="mt-2 text-sm leading-relaxed text-zinc-400">{fix.desc}</p>
                {fix.items.length > 0 && (
                  <ul className="mt-3 space-y-1.5">
                    {fix.items.map((item, j) => (
                      <li key={j} className="flex gap-2 text-sm text-zinc-300">
                        <span className="text-orange-400">▸</span>
                        <code className="text-xs leading-5 text-orange-200">{item}</code>
                      </li>
                    ))}
                  </ul>
                )}
              </article>
            ))}
          </section>
        )}

        {tab === "advice" && (
          <section className="space-y-4">
            <h2 className="text-xl font-bold">③ 前端建议清单（需业务决策，未动代码）</h2>
            {ADVICE.map((item, i) => (
              <article key={i} className="flex items-start gap-3 rounded-xl border border-white/10 bg-white/[0.03] p-4">
                <span
                  className={`mt-0.5 shrink-0 rounded px-2 py-0.5 text-xs font-bold ${
                    item.level === "高" ? "bg-rose-500/15 text-rose-300" : item.level === "中" ? "bg-amber-500/15 text-amber-300" : "bg-sky-500/15 text-sky-300"
                  }`}
                >
                  {item.level}优先级
                </span>
                <p className="text-sm leading-relaxed text-zinc-300">{item.text}</p>
              </article>
            ))}
          </section>
        )}

        {tab === "medusa" && (
          <section className="space-y-4">
            <h2 className="text-xl font-bold">④ Medusa 后端建议（前端改不了，仅建议）</h2>
            {MEDUSA_ADVICE.map((item, i) => (
              <article key={i} className="flex items-start gap-3 rounded-xl border border-white/10 bg-white/[0.03] p-4">
                <span className="mt-0.5 shrink-0 font-mono text-xs text-orange-400">{String(i + 1).padStart(2, "0")}</span>
                <p className="text-sm leading-relaxed text-zinc-300">{item}</p>
              </article>
            ))}
          </section>
        )}

        {tab === "verify" && (
          <section className="space-y-4">
            <h2 className="text-xl font-bold">⑤ 验证结果（全部通过）</h2>
            {VERIFY.map((item, i) => (
              <article key={i} className="flex flex-wrap items-center justify-between gap-2 rounded-xl border border-white/10 bg-white/[0.03] p-4">
                <span className="text-sm text-zinc-300">{item.label}</span>
                <span className="rounded bg-emerald-500/15 px-2.5 py-1 text-xs font-semibold text-emerald-300">
                  ✓ {item.result}
                </span>
              </article>
            ))}
            <div className="rounded-xl border border-orange-500/20 bg-orange-500/5 p-5 text-sm leading-relaxed text-zinc-300">
              <strong className="text-orange-300">目录结构说明：</strong>
              <ul className="mt-2 list-disc space-y-1 pl-5">
                <li><code className="text-orange-200">toonhub-astro/</code> —— 正式独立站工程（Astro + Medusa），直接拿去开发部署；</li>
                <li><code className="text-orange-200">src/</code>（本 React 工程）—— arena 展示壳，随时可删除，不影响 Astro 项目；</li>
                <li><code className="text-orange-200">toonhub-astro/AUDIT.md</code> —— 完整审计报告（Bug 明细、优化说明、建议清单、运行说明）。</li>
              </ul>
            </div>
          </section>
        )}
      </main>

      <footer className="border-t border-white/10 py-6 text-center text-xs text-zinc-500">
        TOONHUB Storefront Audit · Astro theme fixed &amp; optimized · React wrapper is disposable
      </footer>
    </div>
  );
}
