# Toonhub Astro — 审计报告与优化记录

> 2026 年全面审计 + 修复 + 优化。全部改动已通过 `astro check`（0 错误）、
> `astro build` 和 `vitest run`（120 个测试全部通过）。

---

## 一、本次修复的 Bug

| # | 位置 | 问题 | 修复 |
|---|------|------|------|
| 1 | `package.json` | `src/pages/img/[size]/[...path].ts` 动态 `import("sharp")`,但 sharp 不在依赖列表。npm 下是传递依赖碰巧可用,**pnpm 严格模式下必然失败**,且 Astro 升级即断。 | sharp 加入 `dependencies`(`^0.35.4`) |
| 2 | `package.json` | `pg` 依赖从未被使用(遗留) | 已移除 |
| 3 | `src/lib/images.ts` + `src/lib/fallback.ts` | 集合图映射错误:**Naruto 显示 Solo Leveling 图、Tokyo Revengers 显示 Sailor Moon 图、Digimon 显示 Gundam 图** | 生成 3 张正确封面图(naruto / tokyo-revengers / digimon .webp),修正两处映射 |
| 4 | `src/pages/api/cart/add.ts` `update.ts` `remove.ts` | 无任何入参校验:负数/超大数量、空 cartId/variantId 直接打向 Medusa | 校验必填字段,数量限制 1–99,返回 400 与明确错误信息 |
| 5 | `src/pages/api/reviews.ts` | 评分可为 99、文本可无限长,可被刷评/灌水滥用 | 评分钳制 1–5,内容 2000 字、标题 200 字、名字 100 字上限,图片最多 5 张 |
| 6 | `src/pages/api/newsletter.ts` | 邮箱校验仅 `includes("@")`,`"a@b"` 都能过 | 严格邮箱正则 + 254 长度上限 |
| 7 | `src/lib/site.ts` | `instagram/tiktok` 是 `instagram.com` 首页占位链接,Organization JSON-LD 的 `sameAs` 指向首页会被 Google 判为无效外链 | 置空并在注释说明;填真实主页后自动恢复 |

## 二、本次实现的前端优化

### 1. 电商转化事件埋点(此前完全缺失 ❗)
审计发现全站**没有任何 GA4 / GTM / Meta Pixel 代码**,只有匿名行为上报 —— 广告投放无法回传转化,这是独立站最大的数据黑洞。

- 新增 `src/scripts/lib/analytics.ts`:零依赖事件中心,统一 push 到 `window.dataLayer`(GA4/GTM 通用协议)+ 有 Pixel 时同步 `fbq('track',…)`;
- 事件覆盖 GA4 推荐全漏斗:
  - `view_item` — PDP 首屏曝光(`scripts/pdp.ts`);
  - `add_to_cart` — 加购成功,含商品/价格/数量(`scripts/cart.ts`);
  - `begin_checkout` — 进入结账页(`scripts/checkout.ts`);
  - `purchase` — 下单成功,含订单号/金额/币种(`checkout/success.astro`,服务端注入无需二次请求)。
- `layouts/Base.astro` 增加环境变量驱动的加载器:`GA4_ID` / `GTM_ID` / `FB_PIXEL_ID`(任一配置才输出脚本,未配置时零广告脚本);
- `checkout.ts` 成功跳转带 `total` + `currency` 参数,供 purchase 事件与后续推荐使用。

### 2. 商品结构化数据增强(Google 富结果)
- `productJsonLd()` 增加 `shippingDetails`(全球免运费)、`hasMerchantReturnPolicy`(30 天退货)、`priceValidUntil` —— 搜索结果可获得"免运费/可退货"徽标,提升 CTR。

### 3. 安全加固
- 上述购物车/评论/订阅接口入参校验(见 Bug 表 #4–6)。

---

## 三、独立站前端建议清单(未实现项)

以下建议因需要业务决策或后端配合,未改动代码,供参考:

| 优先级 | 建议 | 说明 |
|--------|------|------|
| 🔴 高 | **社交账号真实化** | 站内无任何真实社媒链接;补上 Instagram/TikTok/Facebook 主页(见 Bug #7 注释处) |
| 🔴 高 | **CSP 安全头** | `middleware.ts` 已有基础头;上 CDN 后建议加 Content-Security-Policy(需收集所有内联脚本哈希,建议让 GTM 托管所有营销脚本) |
| 🔴 高 | **滚动倒计时暗模式** | `SALE_WINDOW_DAYS` 是"每访客 3 天滚动结束"的假倒计时,长期伤害转化与品牌信任;建议改成真实促销日历(后端配置) |
| 🟡 中 | **结算前地址校验** | 目前地址基本不做格式校验;建议接入 Google Address Autocomplete + 邮编格式库 |
| 🟡 中 | **订单状态页** | 已有 `/track-order`,建议支持一键注册为账号、加购重购(数据已在 localStorage 的 `toonhub_orders`) |
| 🟡 中 | **多语言路由** | `i18n` 字典已备好(zh-Hant/ja),但目前是"访客级协商"而非 URL 级;等商品描述有多语言后再上 `/ja/…` 目录,并同步 hreflang |
| 🟡 中 | **评论审核** | 评论提交直通 Medusa;建议后端加审核队列(见下方后端建议) |
| 🟢 低 | **搜索同义词** | `/api/search` 直查 Medusa;可加同义词表(如 "shikishi" → "色纸")提高命中 |
| 🟢 低 | **A/B 测试位** | 首页 offer 文案、CTA 颜色建议留 A/B 实验开关 |

## 四、Medusa 后端建议(前端无法修改的部分)

1. **支付回调幂等**:确认 Stripe/PayPal webhook 幂等处理,防止重复发货/重复扣款;
2. **订单邮件**:成功页提示会发邮件 —— 确认 Medusa 配置了 SMTP/OrderPlaced 通知模板;
3. **评论审核**:前端已做长度限制,建议后端加审核状态(draft → published)与脏词过滤;
4. **速率限制**:`/api/reviews`、`/api/contact`、`/api/newsletter` 建议在网关(Cloudflare/Nginx)加 rate limit,防止刷评/垃圾订阅;
5. **优惠码自动应用**:前端自动打 B1G2 折扣码依赖 `promo.ts` 读取后端配置 —— 建议后端把"当前促销 code/折扣率/开关"做成 `/store/promo` 单一接口(现在可能多路径猜测);
6. **多币种**:前端用静态汇率换算展示,但结账仍是 USD —— 建议后端开多区域(Regions)+ 价格表(Price Lists),或明确只收 USD 并在前台弱化币种选择;
7. **运费**:`isConfiguredShip()` 过滤了占位运费(0.1/1/5 档),说明后端运费档还没配好 —— 建议配置真实运费档(免运费规则 + 备选);
8. **库存**:建议后端开启 inventory 模块并在 variant 上维护真实库存,前端缺货自动显示 InStock/OutOfStock(已有结构化数据,但需要真实数据源)。

---

## 五、运行说明

```bash
# 要求 Node >= 22.12(package.json engines)
npm install
cp .env.example .env   # 填入 MEDUSA_URL / MEDUSA_PUBLISHABLE_KEY
npm run dev            # 开发 http://localhost:8888
npm run build          # 构建(dist/,node standalone)
npm test               # vitest 测试
```

### 新增环境变量(可选)
```
GA4_ID=G-XXXXXXXXXX      # Google Analytics 4(或 PUBLIC_GA4_ID)
GTM_ID=GTM-XXXXXX        # Google Tag Manager(与 GA4 二选一)
FB_PIXEL_ID=XXXXXXXXXX   # Meta Pixel
DEMO_CATALOG=off         # 关闭演示目录(后端不可用时不再兜底展示示例数据)
```
