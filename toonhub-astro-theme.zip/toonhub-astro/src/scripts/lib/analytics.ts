/**
 * 电商事件埋点(e-commerce analytics)。
 *
 * 设计原则:
 * - **零依赖、无副作用**:未配置 GA4/GTM/Pixel 时,push 到 dataLayer 只是
 *   数组操作,不影响页面。Base.astro 只在设置了对应环境变量时输出加载器。
 * - **GTM 优先**:`window.dataLayer` 是 GTM 与 GA4 (gtag.js) 的通用协议,
 *   事件名与 GA4 推荐事件对齐(add_to_cart / begin_checkout / view_item /
 *   purchase),营销团队在 GTM 里建标签即可,无需改前端。
 * - **金额单位**:GA4 事件参数 value 使用"主币种+主要单位"(如 29.00),
 *   与 ecommerce.items[].price 保持一致;币种取活跃展示币种。
 */

export interface EcommerceItem {
  item_id: string
  item_name: string
  item_variant?: string
  price?: number
  quantity?: number
  currency?: string
}

declare global {
  interface Window {
    dataLayer?: unknown[]
    fbq?: (...args: unknown[]) => void
  }
}

function pushDataLayer(event: string, payload: Record<string, unknown>): void {
  try {
    window.dataLayer = window.dataLayer || []
    window.dataLayer.push({ event, ...payload, ts: Date.now() })
  } catch {
    /* 埋点失败不影响购物流程 */
  }
}

function pushFbq(event: string, payload: Record<string, unknown>): void {
  try {
    if (typeof window.fbq === "function") window.fbq("track", event, payload)
  } catch {
    /* Pixel 未配置时静默 */
  }
}

/** 主单位金额(美元小数),GA4 的 value 字段约定。 */
function major(value: unknown): number {
  return Math.round((Number(value) || 0)) / 100
}

export function trackEvent(
  event: string,
  payload: Record<string, unknown> = {},
): void {
  pushDataLayer(event, payload)
  pushFbq(event, payload)
}

/** 商品卡片/快速视图/加购共用:一条 ecommerce item。 */
export function itemData(
  id: string,
  name: string,
  priceMinorUsd: number,
  currency: string,
  variantTitle?: string,
): EcommerceItem {
  return {
    item_id: id || "",
    item_name: String(name || "").slice(0, 200),
    ...(variantTitle ? { item_variant: String(variantTitle).slice(0, 100) } : {}),
    price: major(priceMinorUsd),
    currency,
  }
}

/** add_to_cart — 在成功加入购物车后触发(本地回退与远程同步均可)。 */
export function trackAddToCart(
  item: EcommerceItem,
  quantity: number,
  cartCount: number,
): void {
  trackEvent("add_to_cart", {
    ecommerce: {
      currency: item.currency,
      value: major((item.price ?? 0) * 100 * quantity),
      items: [{ ...item, quantity }],
    },
    cart_count: cartCount,
  })
}

/** view_item — PDP 首屏商品曝光。 */
export function trackViewItem(item: EcommerceItem): void {
  trackEvent("view_item", {
    ecommerce: { currency: item.currency, value: item.price ?? 0, items: [item] },
  })
}

/** begin_checkout — 进入结账第一步。 */
export function trackBeginCheckout(
  items: EcommerceItem[],
  valueMajor: number,
  currency: string,
): void {
  trackEvent("begin_checkout", {
    ecommerce: { currency, value: valueMajor, items },
  })
}

/** purchase — 下单成功页触发,金额用主单位。 */
export function trackPurchase(params: {
  transaction_id: string
  value: number
  currency: string
  items: EcommerceItem[]
}): void {
  const { transaction_id, value, currency, items } = params
  trackEvent("purchase", {
    ecommerce: {
      transaction_id,
      value,
      currency,
      items,
    },
  })
}
