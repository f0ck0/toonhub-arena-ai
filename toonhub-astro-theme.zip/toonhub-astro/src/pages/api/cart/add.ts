import type { APIRoute } from "astro"
import { getStoreSdk } from "../../../lib/medusa-config"
import { errorMessage } from "../../../lib/server-medusa"

export const prerender = false

export const POST: APIRoute = async ({ request }) => {
  try {
    const { cartId, variantId, quantity } = await request.json()
    const id = String(cartId || "").trim()
    const variant = String(variantId || "").trim()
    const qty = Math.floor(Number(quantity))
    if (!id || !variant) {
      return new Response(JSON.stringify({ error: "cartId and variantId are required" }), { status: 400, headers: { "Content-Type": "application/json" } })
    }
    if (!Number.isFinite(qty) || qty < 1 || qty > 99) {
      return new Response(JSON.stringify({ error: "quantity must be between 1 and 99" }), { status: 400, headers: { "Content-Type": "application/json" } })
    }
    const medusa = getStoreSdk()
    const { cart } = await medusa.store.cart.createLineItem(id, { variant_id: variant, quantity: qty })
    return new Response(JSON.stringify({ success: true, cart }), { status: 200, headers: { "Content-Type": "application/json" } })
  } catch (e) {
    return new Response(JSON.stringify({ error: errorMessage(e) }), { status: 500, headers: { "Content-Type": "application/json" } })
  }
}
